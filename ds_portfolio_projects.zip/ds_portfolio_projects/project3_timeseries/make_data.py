import numpy as np
import pandas as pd

np.random.seed(42)

# 2 years of daily data
dates = pd.date_range(start="2024-01-01", periods=730, freq="D")
t = np.arange(len(dates))

# Trend: sales slowly growing over time
trend = 500 + t * 0.8

# Weekly seasonality: weekends have higher sales
day_of_week = dates.dayofweek  # 0=Mon ... 6=Sun
weekly_pattern = np.where(day_of_week >= 5, 150, 0)  # boost on Sat/Sun

# Yearly seasonality: higher sales in Nov-Dec (holiday season)
month = dates.month
yearly_pattern = np.where((month == 11) | (month == 12), 200, 0)

# Noise
noise = np.random.normal(0, 40, len(dates))

sales = trend + weekly_pattern + yearly_pattern + noise
sales = sales.clip(min=100)

df = pd.DataFrame({"date": dates, "sales": sales.round(0)})
df.to_csv("daily_sales.csv", index=False)
print(df.head())
print(f"\nShape: {df.shape}")
print(f"Date range: {df['date'].min()} to {df['date'].max()}")
