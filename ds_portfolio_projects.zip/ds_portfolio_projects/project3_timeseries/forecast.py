import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

df = pd.read_csv("daily_sales.csv", parse_dates=["date"])
split_date = df["date"].max() - pd.Timedelta(days=60)
train = df[df["date"] <= split_date].copy()
test = df[df["date"] > split_date].copy()

def build_features(data, t0):
    """Turn dates into numeric features a model can learn from:
    - t: days since start (captures TREND)
    - Fourier terms: sine/cosine waves (captures SEASONALITY - this is the
      same core trick Prophet uses internally)
    """
    t = (data["date"] - t0).dt.days.values.reshape(-1, 1)
    feats = [t]
    # Weekly seasonality (period = 7 days)
    feats.append(np.sin(2 * np.pi * t / 7))
    feats.append(np.cos(2 * np.pi * t / 7))
    # Yearly seasonality (period = 365.25 days)
    feats.append(np.sin(2 * np.pi * t / 365.25))
    feats.append(np.cos(2 * np.pi * t / 365.25))
    return np.hstack(feats)

t0 = train["date"].min()
X_train = build_features(train, t0)
y_train = train["sales"].values
X_test = build_features(test, t0)
y_test = test["sales"].values

model = LinearRegression()
model.fit(X_train, y_train)

pred_train = model.predict(X_train)
pred_test = model.predict(X_test)

rmse_test = np.sqrt(mean_squared_error(y_test, pred_test))
print(f"Test RMSE: {rmse_test:.1f} sales/day")
print(f"(For context, average daily sales: {df['sales'].mean():.0f})")

# Save for plotting
train["predicted"] = pred_train
test["predicted"] = pred_test
train.to_csv("train_with_pred.csv", index=False)
test.to_csv("test_with_pred.csv", index=False)
