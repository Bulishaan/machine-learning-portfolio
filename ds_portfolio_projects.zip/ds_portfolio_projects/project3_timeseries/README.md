# Daily Sales Forecasting — Trend & Seasonality Decomposition

## Overview
A time-series forecasting project predicting daily sales using a trend + seasonality model (weekly and yearly patterns), built from first principles using Linear Regression with Fourier-term features.

**Note:** this version was built manually (trend + sine/cosine seasonality terms) because the Prophet library was unavailable in the working environment. The same dataset and approach translate directly to Prophet — see "Next steps" below for the equivalent Prophet code.

## What I did
1. Generated/loaded a daily sales dataset (2 years) containing trend, weekly seasonality, and yearly (holiday) seasonality
2. Visualized the raw series to identify these patterns before modeling
3. Split the data **by time** (not randomly) — trained on all but the last 60 days, tested on the most recent 60 days, to reflect how real forecasting works
4. Engineered features: days since start (trend) and sine/cosine terms at 7-day and 365-day periods (seasonality) — the same underlying technique Prophet uses internally
5. Trained a Linear Regression model on these features
6. Evaluated forecast accuracy with RMSE on the held-out test period
7. Visualized forecast vs. actual, and diagnosed a limitation: the model underestimated the strength of the holiday season effect, likely due to only one prior year of holiday data to learn from

## Results
- **Test RMSE:** ~148 sales/day (vs. an average of ~867 sales/day)
- Weekly seasonality pattern was captured accurately
- Yearly/holiday effect was underestimated — a known limitation discussed below

## Limitations & how I'd improve it
- More historical years would help the model learn the holiday effect more reliably
- Prophet supports explicit holiday/event windows, which would likely capture the Nov-Dec boost better than generic yearly seasonality
- Could weight recent seasons more heavily than older ones

## Next steps — Prophet version
```python
from prophet import Prophet
df_prophet = df.rename(columns={"date": "ds", "sales": "y"})
model = Prophet(yearly_seasonality=True, weekly_seasonality=True)
model.fit(df_prophet[df_prophet["ds"] <= split_date])
future = model.make_future_dataframe(periods=60)
forecast = model.predict(future)
model.plot(forecast)
model.plot_components(forecast)
```

## Tools
Python, pandas, scikit-learn, NumPy, matplotlib

## Key concepts demonstrated
- Time-based train/test splitting (vs. random splitting for non-time-series data)
- Trend and seasonality decomposition
- Fourier-term feature engineering for cyclical patterns
- Honest evaluation of model limitations
