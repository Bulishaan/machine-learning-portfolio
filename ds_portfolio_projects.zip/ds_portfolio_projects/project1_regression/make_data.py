import numpy as np
import pandas as pd

np.random.seed(42)
n = 500

# Features that realistically influence house price
sqft = np.random.normal(1800, 600, n).clip(400, 5000)
bedrooms = np.random.randint(1, 6, n)
bathrooms = np.random.randint(1, 4, n)
age = np.random.randint(0, 80, n)
distance_to_city_km = np.random.exponential(8, n).clip(0.5, 40)

# Price formula with some realistic logic + noise
price = (
    sqft * 150
    + bedrooms * 8000
    + bathrooms * 6000
    - age * 500
    - distance_to_city_km * 1200
    + np.random.normal(0, 15000, n)
)
price = price.clip(50000, None)

df = pd.DataFrame({
    "sqft": sqft.round(0),
    "bedrooms": bedrooms,
    "bathrooms": bathrooms,
    "age_years": age,
    "distance_to_city_km": distance_to_city_km.round(1),
    "price": price.round(0),
})

df.to_csv("house_prices.csv", index=False)
print(df.head())
print(f"\nShape: {df.shape}")
