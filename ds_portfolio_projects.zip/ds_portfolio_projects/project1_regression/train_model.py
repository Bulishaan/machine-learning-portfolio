import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np

df = pd.read_csv("house_prices.csv")

X = df.drop("price", axis=1)
y = df["price"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train the model
model = LinearRegression()
model.fit(X_train, y_train)

# Make predictions on the TEST set (data the model has never seen)
y_pred = model.predict(X_test)

# Evaluate
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
r2 = r2_score(y_test, y_pred)

print(f"RMSE (Root Mean Squared Error): ${rmse:,.0f}")
print(f"R² Score: {r2:.3f}")
print()
print("What each feature contributes to price (coefficients):")
for feature, coef in zip(X.columns, model.coef_):
    print(f"  {feature}: {coef:,.1f}")
print(f"  intercept (base price): {model.intercept_:,.1f}")

# Show a few actual vs predicted examples
print()
print("Sample predictions vs actual (first 5 test rows):")
comparison = pd.DataFrame({"actual": y_test.values[:5], "predicted": y_pred[:5].round(0)})
print(comparison)
