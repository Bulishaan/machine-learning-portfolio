# House Price Prediction — Linear Regression

## Overview
A supervised machine learning project predicting house prices from property features (square footage, bedrooms, bathrooms, age, distance to city center) using Linear Regression.

**Note:** this version uses a synthetic dataset generated to mirror the structure of Kaggle's House Prices dataset. Recommended next step: rerun the same pipeline on the real dataset at [kaggle.com/competitions/house-prices-advanced-regression-techniques](https://www.kaggle.com/competitions/house-prices-advanced-regression-techniques).

## What I did
1. Loaded and explored the dataset — checked shape, missing values, summary statistics
2. Split data into training (80%) and test (20%) sets using `train_test_split`
3. Trained a Linear Regression model with scikit-learn
4. Evaluated performance using RMSE and R²
5. Interpreted model coefficients to understand which features drive price
6. Visualized actual vs. predicted prices to check model quality

## Results
- **RMSE:** ~$15,000 (average prediction error)
- **R²:** 0.97 (proportion of price variation explained by the model)
- Square footage and bedrooms/bathrooms increase price; age and distance from city center decrease it — all consistent with real-world intuition

## Tools
Python, pandas, scikit-learn, matplotlib, NumPy

## Key concepts demonstrated
- Supervised learning workflow
- Train/test split and why it matters (avoiding data leakage)
- Regression evaluation metrics (RMSE, R²)
- Model interpretability via coefficients
