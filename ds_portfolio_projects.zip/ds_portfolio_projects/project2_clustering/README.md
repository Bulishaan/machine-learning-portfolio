# Customer Segmentation — K-Means Clustering

## Overview
An unsupervised machine learning project grouping customers into segments based on age, annual income, and spending behavior, using K-Means clustering.

**Note:** this version uses a synthetic dataset generated to mirror the structure of Kaggle's Mall Customer Segmentation dataset. Recommended next step: rerun the same pipeline on the real dataset at [kaggle.com/datasets/vjchoudhary7/customer-segmentation-tutorial-in-python](https://www.kaggle.com/datasets/vjchoudhary7/customer-segmentation-tutorial-in-python).

## What I did
1. Loaded and explored the customer dataset
2. Standardized features (age, income, spending score) using `StandardScaler` — necessary since features are on different scales
3. Used the elbow method to choose the optimal number of clusters (k=4)
4. Applied K-Means clustering to group customers
5. Interpreted each cluster's average profile and assigned business meaning
6. Visualized clusters on an income vs. spending score plot

## Results
Four distinct customer segments were identified:
- **High income, high spending** — premium customers worth retaining
- **High income, low spending** — savers, potential targets for engagement campaigns
- **Low income, high spending** — impulsive spenders, may carry higher risk
- **Low income, low spending** — price-sensitive, low-priority segment

## Tools
Python, pandas, scikit-learn, matplotlib

## Key concepts demonstrated
- Unsupervised learning (no target variable)
- Feature scaling and why it's necessary for distance-based algorithms
- The elbow method for choosing k
- Translating clustering output into actionable business insight
