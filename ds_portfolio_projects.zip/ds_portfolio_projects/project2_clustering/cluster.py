import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

df = pd.read_csv("customers.csv")
features = df[["age", "annual_income_k", "spending_score"]]

scaler = StandardScaler()
scaled = scaler.fit_transform(features)

# --- Elbow method: how do we choose the number of clusters (k)? ---
inertias = []
k_range = range(1, 10)
for k in k_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    km.fit(scaled)
    inertias.append(km.inertia_)

plt.figure(figsize=(7, 5))
plt.plot(list(k_range), inertias, marker="o", color="#1F2A44")
plt.xlabel("Number of clusters (k)")
plt.ylabel("Inertia (within-cluster variance)")
plt.title("Elbow Method for Choosing k")
plt.tight_layout()
plt.savefig("elbow_plot.png", dpi=120)
print("Elbow plot saved.")

# --- Fit final model with k=4 (chosen from the elbow) ---
kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
df["cluster"] = kmeans.fit_predict(scaled)

print()
print("Cluster sizes:")
print(df["cluster"].value_counts().sort_index())

print()
print("Average profile per cluster:")
print(df.groupby("cluster")[["age", "annual_income_k", "spending_score"]].mean().round(1))

df.to_csv("customers_clustered.csv", index=False)
