import numpy as np
import pandas as pd

np.random.seed(42)

# Simulate 4 natural customer groups (in reality we wouldn't know this in advance —
# clustering's job is to discover it)
def make_group(n, income_mean, income_std, spend_mean, spend_std, age_mean, age_std):
    return pd.DataFrame({
        "annual_income_k": np.random.normal(income_mean, income_std, n).clip(15, 150),
        "spending_score": np.random.normal(spend_mean, spend_std, n).clip(1, 100),
        "age": np.random.normal(age_mean, age_std, n).clip(18, 75).astype(int),
    })

g1 = make_group(60, 25, 8, 20, 10, 25, 5)    # young, low income, low spenders
g2 = make_group(60, 30, 8, 80, 10, 30, 6)    # young, low income, HIGH spenders (impulsive)
g3 = make_group(60, 90, 15, 20, 10, 45, 8)   # high income, low spenders (savers)
g4 = make_group(60, 85, 15, 80, 10, 40, 7)   # high income, high spenders

df = pd.concat([g1, g2, g3, g4], ignore_index=True)
df = df.sample(frac=1, random_state=42).reset_index(drop=True)  # shuffle
df["customer_id"] = range(1, len(df) + 1)
df = df[["customer_id", "age", "annual_income_k", "spending_score"]]
df.to_csv("customers.csv", index=False)
print(df.head())
print(f"\nShape: {df.shape}")
